%% 基于多径信道的无线通信系统

clear all; close all; clc;

%% PBL任务 1.1 & 2.1: 系统基本参数与输入信号设定
% 1. 系统基本参数
fs = 1000;             % 采样频率 (Hz)
Ts = 1/fs;             % 采样周期
t_max = 0.5;           % 总仿真时间 (秒)
t = 0:Ts:t_max-Ts;     % 时间向量
N = length(t);         % 样本数

% 2. 生成确定性测试比特序列 (PBL任务 2.1: 设定BPSK信号作为输入)
test_bits = [1 0 1 0 1 1 0 0 1 0]; % 确定性测试序列
bit_length = length(test_bits);
bit_rate = 20;         % 极低比特率，每比特有大量样本
samples_per_bit = floor(fs/bit_rate); % 每比特的样本数

% 3. 生成基带信号 - BPSK调制
bpsk_signal = zeros(1, N);
for i = 1:bit_length
    bit_start = (i-1)*samples_per_bit + 1;
    bit_end = min(i*samples_per_bit, N);

    if bit_start <= N && bit_end >= bit_start
        if test_bits(i) == 1
            bpsk_signal(bit_start:bit_end) = 1;
        else
            bpsk_signal(bit_start:bit_end) = -1;
        end
    end
end

active_length = min(bit_length * samples_per_bit, N);
bpsk_signal = bpsk_signal(1:active_length);
t_active = t(1:active_length);

figure;
subplot(3,1,1); 
plot(t_active, bpsk_signal);
title('原始BPSK信号 (PBL任务 2.1)');
xlabel('时间 (秒)');
ylabel('幅度');
grid on;
ylim([-1.5 1.5]);

%% PBL任务 1.1: 信道建模 (设定不同的路径增益与时延参数)

% 三径信道参数
path_gains = [0.8, 0.5, 0.3];         % 三径的增益
path_delays_samples = [0, 2, 5];     % 对应增益的路径延迟 (样本数)

% 构建信道冲激响应 h(n)
max_delay = max(path_delays_samples);
h_channel_full = zeros(1, max_delay + 1);
for k = 1:length(path_gains)
    h_channel_full(path_delays_samples(k) + 1) = path_gains(k);
end

%% PBL任务 1.2: 分析信道的冲激响应与系统函数
disp('====== PBL任务 1.2: 三径信道特性 ======');
disp('信道冲激响应 h(n):');
disp(h_channel_full);

% 系统函数 H(z) - Z变换 (离散时间傅里叶变换 DTFT是 H(z) 在单位圆上的取值)
% 对于FIR滤波器, H(z) = h(0) + h(1)z^-1 + h(2)z^-2 + ...
% 这里我们主要通过其频率响应 H(e^jω) 来分析
H_channel_freq_response = fft(h_channel_full, active_length); % 计算频率响应 (DTFT的采样)
f_axis = (0:active_length-1)*fs/active_length; % 频率轴

figure;
subplot(2,1,1);
stem(0:length(h_channel_full)-1, h_channel_full);
title('三径信道冲激响应 h(n) (PBL任务 1.2)');
xlabel('样本数 n');
ylabel('幅度');
grid on;

subplot(2,1,2);
plot(f_axis(1:active_length/2), abs(H_channel_freq_response(1:active_length/2)));
title('三径信道系统函数 (幅度谱) |H(e^{j\omega})| (PBL任务 1.2)');
xlabel('频率 (Hz)');
ylabel('幅度');
grid on;

%% PBL任务 2.2 & 2.3: 信号传输仿真及观察分析
% 信号通过三径信道 (卷积)
y_channel_output = conv(bpsk_signal, h_channel_full);
y_channel_output = y_channel_output(1:active_length); % 截断到原始长度

% 添加高斯白噪声 (AWGN)
SNR_dB = 20; % 可以调整SNR观察效果, PBL要求评估SNR改善，所以初始SNR不宜过高
SNR_linear = 10^(SNR_dB/10);
signal_power_at_channel_output = sum(abs(y_channel_output).^2)/active_length;
noise_power = signal_power_at_channel_output/SNR_linear; % 以信道输出信号功率为基准定义SNR
noise = sqrt(noise_power) * randn(1, active_length);
y_received_noisy = y_channel_output + noise;

% 可视化信号变化 (PBL任务 2.3: 观察波形、幅度衰落、时延失真)
figure(1); 
subplot(3,1,2);
plot(t_active, y_channel_output);
title('信号通过三径信道后 (无噪声) (PBL任务 2.2 & 2.3)');
xlabel('时间 (秒)');
ylabel('幅度');
grid on;

subplot(3,1,3);
plot(t_active, y_received_noisy);
title(['接收信号 (含噪声, SNR = ', num2str(SNR_dB), 'dB) (PBL任务 2.2 & 2.3)']);
xlabel('时间 (秒)');
ylabel('幅度');
grid on;
% 从图中可以看到信号幅度不再是简单的+1/-1，出现平滑和拖尾，这就是幅度衰落和时延失真

%% PBL任务 3.1: 频域分析 - 发送与接收信号频谱比较
Y_bpsk_freq = fft(bpsk_signal);
Y_received_freq = fft(y_received_noisy);

figure;
subplot(2,1,1);
plot(f_axis(1:active_length/2), abs(Y_bpsk_freq(1:active_length/2)));
hold on;
plot(f_axis(1:active_length/2), abs(Y_received_freq(1:active_length/2)), 'r');
hold off;
title('发送信号与接收信号频谱比较 (PBL任务 3.1)');
xlabel('频率 (Hz)');
ylabel('幅度');
legend('发送信号频谱', '接收信号频谱');
grid on;

%% PBL任务 3.2: 评估信道对不同频率成分的影响，并探讨等效带宽的变化
% 信道对不同频率成分的影响已在PBL任务1.2中通过H_channel_freq_response展示
% 等效带宽讨论：
% 原始BPSK信号的带宽主要集中在第一个零点之前，大约是比特率的两倍。
% 观察H_channel_freq_response的幅度谱，如果出现深衰落点，
% 那么在这些频率点上的信号能量将严重损失。
% 信道的等效带宽可以理解为信道能够有效传输信号的频率范围。
% 如果信道在某些频段衰减严重，会使得接收信号的有效带宽减小，或者说在这些频段的SNR恶化。
% 例如，可以定义信道带宽为幅度谱从最大值下降到-3dB (或一半功率)的频率范围。
disp('====== PBL任务 3.2: 信道影响与带宽 ======');
max_H_abs = max(abs(H_channel_freq_response(1:active_length/2)));
% 示例：找到第一个幅度下降到最大值70.7% (-3dB) 的点（简化单边）
idx_3dB = find(abs(H_channel_freq_response(1:active_length/2)) < max_H_abs/sqrt(2), 1, 'first');
if ~isempty(idx_3dB) && idx_3dB > 1 %确保不是从DC开始就衰减
    channel_equiv_bandwidth_3dB = f_axis(idx_3dB);
    disp(['信道近似-3dB带宽 (单边, 简化估计): ', num2str(channel_equiv_bandwidth_3dB), ' Hz']);
    figure(3); % 在上一个figure继续绘图
    subplot(2,1,2);
    plot(f_axis(1:active_length/2), abs(H_channel_freq_response(1:active_length/2)));
    hold on;
    plot(f_axis(1:active_length/2), 20*log10(abs(H_channel_freq_response(1:active_length/2))/max_H_abs), 'k--'); % dB
    plot([channel_equiv_bandwidth_3dB, channel_equiv_bandwidth_3dB], ylim, 'r--');
    text(channel_equiv_bandwidth_3dB, 0, [' \leftarrow -3dB BW approx. ', num2str(channel_equiv_bandwidth_3dB), ' Hz']);
    hold off;
    title('信道频率响应与近似-3dB带宽 (PBL任务 3.2)');
    xlabel('频率 (Hz)');
    ylabel('幅度 / 幅度(dB relative to max)');
    grid on;
    legend('线性幅度','幅度(dB)','-3dB点');
else
    disp('未能简单估计出-3dB带宽，可能信道在低频衰减或太平坦。');
      figure(3); % 在上一个figure继续绘图
    subplot(2,1,2);
    plot(f_axis(1:active_length/2), abs(H_channel_freq_response(1:active_length/2)));
    title('信道频率响应 (PBL任务 3.2)');
    xlabel('频率 (Hz)');
    ylabel('幅度');
    grid on;
end
disp('讨论: 观察信道频率响应图，可以看到某些频率分量被增强，某些被削弱。');
disp('如果信道在信号的主要频率成分处有深衰落，则信号质量会严重下降。');
disp('多径效应通常会导致频率选择性衰落，这会改变信号的频谱形状，影响等效带宽。');


%% PBL任务 4.1: 设计简化的信道均衡器 (匹配滤波器或反卷积方法)
% 我们将实现和比较两种方法

% ===== 匹配滤波器法 (Matched Filter) =====
% 匹配滤波器 h_mf(n) = h_channel^*(-n) (对于实数信道 h_channel(-n))
% 归一化可选，这里是为了尝试恢复信号幅度
h_mf = fliplr(h_channel_full) / sum(h_channel_full.^2); % 与原代码一致的归一化
y_mf_recovered = conv(y_received_noisy, h_mf);
% 补偿延迟 - 匹配滤波器引入额外延迟
mf_delay = length(h_channel_full) - 1;
y_mf_recovered = y_mf_recovered(mf_delay+1 : mf_delay+active_length);

% ===== 反卷积法 (Zero-Forcing Deconvolution) =====
% 零填充以匹配FFT长度
h_zp = [h_channel_full, zeros(1, active_length-length(h_channel_full))];
H_channel_fft = fft(h_zp); % 信道频响

% 加入正则化因子避免除零问题
lambda = 0.01; % 可以调整这个参数
H_inv_freq = conj(H_channel_fft) ./ (abs(H_channel_fft).^2 + lambda); % 逆滤波器频响

% 频域处理
Y_received_fft = fft(y_received_noisy);
Y_eq_freq = Y_received_fft .* H_inv_freq;
y_eq_recovered = real(ifft(Y_eq_freq));

% 可视化恢复信号
figure;
subplot(3,1,1);
plot(t_active, bpsk_signal);
title('原始BPSK信号 (PBL任务 4.1)');
xlabel('时间 (秒)');
ylabel('幅度');
grid on;
ylim([-1.5 1.5]);

subplot(3,1,2);
plot(t_active, y_mf_recovered);
title('匹配滤波器恢复信号 (PBL任务 4.1)');
xlabel('时间 (秒)');
ylabel('幅度');
grid on;

subplot(3,1,3);
plot(t_active, y_eq_recovered);
title('反卷积恢复信号 (PBL任务 4.1)');
xlabel('时间 (秒)');
ylabel('幅度');
grid on;

%% PBL任务 4.2: 验证其对信号恢复的有效性，并评估信噪比(SNR)改善情况
% 首先进行比特判决并计算BER (如原代码)
% 使用原代码中的最佳采样偏移搜索方法

% --- 搜索最佳采样偏移 ---
offset_range = 1:samples_per_bit;
BER_mf_offset = zeros(1, length(offset_range));
BER_eq_offset = zeros(1, length(offset_range));

for offset_idx = 1:length(offset_range)
    offset = offset_range(offset_idx);
    bits_mf_offset = zeros(1, bit_length);
    bits_eq_offset = zeros(1, bit_length);

    for i = 1:bit_length
        bit_sample_point = (i-1)*samples_per_bit + offset;

        if bit_sample_point <= active_length
            % 匹配滤波器判决
            if y_mf_recovered(bit_sample_point) > 0
                bits_mf_offset(i) = 1;
            else
                bits_mf_offset(i) = 0;
            end

            % 反卷积判决
            if y_eq_recovered(bit_sample_point) > 0
                bits_eq_offset(i) = 1;
            else
                bits_eq_offset(i) = 0;
            end
        else % 如果采样点超出信号长度，则赋一个错误值或不计入（这里简单处理）
            bits_mf_offset(i) = ~test_bits(i); % 确保产生错误
            bits_eq_offset(i) = ~test_bits(i);
        end
    end

    BER_mf_offset(offset_idx) = sum(bits_mf_offset(1:bit_length) ~= test_bits(1:bit_length)) / bit_length;
    BER_eq_offset(offset_idx) = sum(bits_eq_offset(1:bit_length) ~= test_bits(1:bit_length)) / bit_length;
end

[min_BER_mf, best_offset_mf_idx] = min(BER_mf_offset);
best_offset_mf = offset_range(best_offset_mf_idx);
[min_BER_eq, best_offset_eq_idx] = min(BER_eq_offset);
best_offset_eq = offset_range(best_offset_eq_idx);

disp('====== PBL任务 4.2: 均衡后性能评估 ======');
disp(['匹配滤波器 - 最佳采样偏移: ', num2str(best_offset_mf), ', 对应最小BER: ', num2str(min_BER_mf)]);
disp(['反卷积方法 - 最佳采样偏移: ', num2str(best_offset_eq), ', 对应最小BER: ', num2str(min_BER_eq)]);

% --- 使用最佳偏移进行最终判决 ---
final_bits_mf = zeros(1, bit_length);
final_bits_eq = zeros(1, bit_length);
y_mf_sampled_points = zeros(1, bit_length); % 用于SNR估计
y_eq_sampled_points = zeros(1, bit_length); % 用于SNR估计

for i = 1:bit_length
    bit_mid_mf = (i-1)*samples_per_bit + best_offset_mf;
    bit_mid_eq = (i-1)*samples_per_bit + best_offset_eq;

    if bit_mid_mf <= active_length
        y_mf_sampled_points(i) = y_mf_recovered(bit_mid_mf);
        if y_mf_recovered(bit_mid_mf) > 0
            final_bits_mf(i) = 1;
        else
            final_bits_mf(i) = 0;
        end
    end

    if bit_mid_eq <= active_length
        y_eq_sampled_points(i) = y_eq_recovered(bit_mid_eq);
        if y_eq_recovered(bit_mid_eq) > 0
            final_bits_eq(i) = 1;
        else
            final_bits_eq(i) = 0;
        end
    end
end

final_BER_mf = sum(final_bits_mf ~= test_bits) / bit_length;
final_BER_eq = sum(final_bits_eq ~= test_bits) / bit_length;

disp('最终比特判决结果（使用最佳偏移）:');
disp('原始比特序列:          '); disp(test_bits);
disp('匹配滤波器恢复比特:  '); disp(final_bits_mf);
disp(['匹配滤波器最终误码率(BER): ', num2str(final_BER_mf)]);
disp('反卷积最终恢复比特:  '); disp(final_bits_eq);
disp(['反卷积方法最终误码率(BER): ', num2str(final_BER_eq)]);

% --- 评估SNR改善情况 ---
% 计算接收端未均衡时的信号功率和噪声功率 (近似)
% 假设判决前的理想信号是 bpsk_signal 通过信道 h_channel_full (无噪声部分)
% 在判决点进行采样
original_signal_at_decision_points = (test_bits*2-1); % 1 -> 1, 0 -> -1 (理想判决值)

% SNR before equalization (at receiver input, but measured effectively at decision points)
% 这是一个粗略的估计，因为y_received_noisy本身就是失真+噪声
% 更准确的输入SNR定义是在y_channel_output基础上加噪那里，即SNR_dB
disp(['输入SNR (设定值): ', num2str(SNR_dB), ' dB']);

% SNR after Matched Filter
% 信号功率：假设恢复的信号中，与理想判决值一致的部分为信号
% 噪声功率：恢复信号与理想判决值之间的差值为噪声+残余ISI
signal_power_mf = sum(original_signal_at_decision_points.^2)/bit_length; % 理想信号功率
noise_plus_isi_power_mf = sum((y_mf_sampled_points - original_signal_at_decision_points).^2)/bit_length;
% 避免除零错误
if noise_plus_isi_power_mf > 0
    SNR_mf_output_dB = 10*log10(signal_power_mf / noise_plus_isi_power_mf);
else
    SNR_mf_output_dB = Inf; % 如果误差为零，SNR无穷大
end
disp(['匹配滤波器输出近似SNR: ', num2str(SNR_mf_output_dB), ' dB']);

% SNR after Deconvolution
signal_power_eq = sum(original_signal_at_decision_points.^2)/bit_length;
noise_plus_isi_power_eq = sum((y_eq_sampled_points - original_signal_at_decision_points).^2)/bit_length;
% 避免除零错误
if noise_plus_isi_power_eq > 0
     SNR_eq_output_dB = 10*log10(signal_power_eq / noise_plus_isi_power_eq);
else
     SNR_eq_output_dB = Inf; % 如果误差为零，SNR无穷大
end

disp(['反卷积均衡器输出近似SNR: ', num2str(SNR_eq_output_dB), ' dB']);

disp('SNR改善讨论: ');
disp(['相较于输入端的设定SNR (', num2str(SNR_dB), ' dB), ']);
if SNR_mf_output_dB > SNR_dB
    disp(['匹配滤波器将有效SNR提升至约 ', num2str(SNR_mf_output_dB), ' dB.']);
else
    disp(['匹配滤波器未能显著提升有效SNR (输出约 ', num2str(SNR_mf_output_dB), ' dB), 可能由于ISI或噪声放大。']);
end
if SNR_eq_output_dB > SNR_dB
    disp(['反卷积均衡器将有效SNR提升至约 ', num2str(SNR_eq_output_dB), ' dB.']);
else
    disp(['反卷积均衡器未能显著提升有效SNR (输出约 ', num2str(SNR_eq_output_dB), ' dB), 可能由于噪声放大。']);
end
disp('注意: 此SNR估算方法较为简化，实际SNR改善评估可能需要更精确地分离信号、ISI和噪声分量。');
disp('BER的降低是均衡有效性的最终体现。');


% --- NMSE ---
% 注意：NMSE比较的是恢复信号与原始基带信号的波形，受均衡器引入的延迟和幅度影响
% 这里的NMSE计算没有补偿延迟，因此可能不是最准确的波形恢复衡量
NMSE_mf = sum((bpsk_signal - y_mf_recovered).^2) / sum(bpsk_signal.^2);
NMSE_eq = sum((bpsk_signal - y_eq_recovered).^2) / sum(bpsk_signal.^2);
disp('归一化均方误差 (NMSE):');
disp(['匹配滤波器 NMSE: ', num2str(NMSE_mf)]);
disp(['反卷积方法 NMSE: ', num2str(NMSE_eq)]);

% --- 绘制BER vs Offset (与原代码一致) ---
figure;
plot(offset_range, BER_mf_offset, 'o-', 'LineWidth', 2);
hold on;
plot(offset_range, BER_eq_offset, 's-', 'LineWidth', 2);
title('不同采样偏移下的误码率 (PBL任务4.2)');
xlabel('采样偏移 (样本)');
ylabel('误码率 (BER)');
legend('匹配滤波器', '反卷积方法');
grid on;

%% 测试更复杂的多径信道 (四路径示例)
% (这部分可以作为报告中的扩展讨论，展示方法的普适性或局限性)
% 此部分代码保持不变，与上述三径信道仿真独立。
disp(' ');
disp('====== 测试另一个更复杂的多径信道 (可选扩展) ======');
path_gains_multi = [0.7, 0.5, 0.3, 0.1];         % 四路径增益
path_delays_multi_samples = [0, 3, 7, 12];     % 四路径延迟
max_delay_multi = max(path_delays_multi_samples);
h_multi_full = zeros(1, max_delay_multi + 1);
for k = 1:length(path_gains_multi)
    h_multi_full(path_delays_multi_samples(k) + 1) = path_gains_multi(k);
end

disp('复杂多径信道冲激响应 h_multi(n):');
disp(h_multi_full);

% 信号通过复杂多径信道
y_multi_channel_output = conv(bpsk_signal, h_multi_full);
y_multi_channel_output = y_multi_channel_output(1:active_length);

% 使用相同的噪声功率进行比较 (或者重新根据y_multi_channel_output调整SNR)
% 为了简化，我们暂时用之前计算的noise_power，但理想情况应重新计算
y_multi_received_noisy = y_multi_channel_output + sqrt(noise_power) * randn(1, active_length); % 使用之前的noise_power

% --- 复杂信道下的恢复 ---
% 匹配滤波器
h_multi_mf = fliplr(h_multi_full) / sum(h_multi_full.^2);
y_multi_mf_recovered = conv(y_multi_received_noisy, h_multi_mf);
multi_mf_delay = length(h_multi_full) - 1;
y_multi_mf_recovered = y_multi_mf_recovered(multi_mf_delay+1 : multi_mf_delay+active_length);

% 反卷积
h_multi_zp = [h_multi_full, zeros(1, active_length-length(h_multi_full))];
H_multi_channel_fft = fft(h_multi_zp);
H_multi_inv_freq = conj(H_multi_channel_fft) ./ (abs(H_multi_channel_fft).^2 + lambda); % lambda保持不变
Y_multi_received_fft = fft(y_multi_received_noisy);
Y_multi_eq_recovered_freq = Y_multi_received_fft .* H_multi_inv_freq;
y_multi_eq_recovered = real(ifft(Y_multi_eq_recovered_freq));

figure;
subplot(4,1,1);
stem(0:length(h_multi_full)-1, h_multi_full);
title('复杂多径信道 h_{multi}(n)');
xlabel('样本数'); ylabel('幅度'); grid on;

subplot(4,1,2);
plot(t_active, y_multi_received_noisy);
title('复杂多径接收信号 (含噪)');
xlabel('时间 (秒)'); ylabel('幅度'); grid on;

subplot(4,1,3);
plot(t_active, y_multi_mf_recovered);
title('匹配滤波器恢复 (复杂多径)');
xlabel('时间 (秒)'); ylabel('幅度'); grid on;

subplot(4,1,4);
plot(t_active, y_multi_eq_recovered);
title('反卷积恢复 (复杂多径)');
xlabel('时间 (秒)'); ylabel('幅度'); grid on;

% 对复杂信道也可以进行BER等性能评估，但为保持脚本简洁，此处省略重复的判决代码
% 可以在报告中讨论，对比不同信道下两种均衡方法的性能变化。

%% 保存关键图像 (根据PBL报告需求调整)
% print('-f1', 'PBL_Signal_Transmission_Tripath.png', '-dpng');
% print('-f2', 'PBL_Channel_Characteristics_Tripath.png', '-dpng');
% print('-f3', 'PBL_Spectrum_Comparison_Tripath.png', '-dpng');
% print('-f4', 'PBL_Recovery_Signals_Tripath.png', '-dpng');
% print('-f5', 'PBL_BER_vs_Offset_Tripath.png', '-dpng');
% print('-f6', 'PBL_Complex_Multipath_Example.png', '-dpng'); % 此图是基于原有的复杂信道

