# MIMO_OFDM-Wireless-Communication

>本仓库为《MIMO-OFDM无线通信技术及MATLAB实现》随书源码。本人将其调试、分类、整理并附上运行结果，以供读者在翻阅书籍时更好的理解知识，并运行相关章节的代码。
